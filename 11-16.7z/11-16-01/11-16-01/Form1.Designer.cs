﻿namespace _11_16_01
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "대한민국",
            "82"}, 88);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "브라질",
            "55"}, 22);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "미국",
            "1"}, 94);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "프랑스",
            "33"}, 57);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
            "이집트",
            "20"}, 49);
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listView1 = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5});
            this.listView1.LargeImageList = this.imageList2;
            this.listView1.Location = new System.Drawing.Point(11, 15);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(269, 483);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.Click += new System.EventHandler(this.listView1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 509);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(326, 104);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 16);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.Text = "큰아이콘";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(448, 104);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(83, 16);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.Text = "작은아이콘";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(326, 180);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(59, 16);
            this.radioButton3.TabIndex = 4;
            this.radioButton3.Text = "리스트";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(448, 180);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(59, 16);
            this.radioButton4.TabIndex = 5;
            this.radioButton4.Text = "자세히";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "AFG-AFGHANISTAN.PNG");
            this.imageList1.Images.SetKeyName(1, "ALB-ALBANIA.PNG");
            this.imageList1.Images.SetKeyName(2, "ALG-ALGERIA.PNG");
            this.imageList1.Images.SetKeyName(3, "AND-ANDORRA.PNG");
            this.imageList1.Images.SetKeyName(4, "ANG-ANGOLA.PNG");
            this.imageList1.Images.SetKeyName(5, "ANT-ANTIGUAAND BARBUDA.PNG");
            this.imageList1.Images.SetKeyName(6, "ARG-ARGENTINA.PNG");
            this.imageList1.Images.SetKeyName(7, "ARM-ARMENIA.PNG");
            this.imageList1.Images.SetKeyName(8, "AUS-AUSTRALIA.PNG");
            this.imageList1.Images.SetKeyName(9, "AUT-AUSTRIA.PNG");
            this.imageList1.Images.SetKeyName(10, "BAH-BAHAMAS.PNG");
            this.imageList1.Images.SetKeyName(11, "BAN-BANGLADESH.PNG");
            this.imageList1.Images.SetKeyName(12, "BAR-BARBADOS.PNG");
            this.imageList1.Images.SetKeyName(13, "BDI-BURUNDI.PNG");
            this.imageList1.Images.SetKeyName(14, "BEL-BELGIUM.PNG");
            this.imageList1.Images.SetKeyName(15, "BEN-BENIN.PNG");
            this.imageList1.Images.SetKeyName(16, "BHU-BHUTAN.PNG");
            this.imageList1.Images.SetKeyName(17, "BIH-BOSNIA AND HERZEGOVINA.PNG");
            this.imageList1.Images.SetKeyName(18, "BIZ-BELIZE.PNG");
            this.imageList1.Images.SetKeyName(19, "BLR-BELARUS.PNG");
            this.imageList1.Images.SetKeyName(20, "BOL-BOLIVIA.PNG");
            this.imageList1.Images.SetKeyName(21, "BOT-BOTSWANA.PNG");
            this.imageList1.Images.SetKeyName(22, "BRA-BRAZIL.PNG");
            this.imageList1.Images.SetKeyName(23, "BRN-BAHRAIN.PNG");
            this.imageList1.Images.SetKeyName(24, "BRU-BRUNEI.PNG");
            this.imageList1.Images.SetKeyName(25, "BUL-BULGARIA.PNG");
            this.imageList1.Images.SetKeyName(26, "BUR-BURKINA FASO.PNG");
            this.imageList1.Images.SetKeyName(27, "CAF-CENTRAL AFRICAN REPUBLIC.PNG");
            this.imageList1.Images.SetKeyName(28, "CAM-CAMBODIA.PNG");
            this.imageList1.Images.SetKeyName(29, "CAN-CANADA.PNG");
            this.imageList1.Images.SetKeyName(30, "CGO-CONGO.PNG");
            this.imageList1.Images.SetKeyName(31, "CHA-CHAD.PNG");
            this.imageList1.Images.SetKeyName(32, "CHI-CHILE.PNG");
            this.imageList1.Images.SetKeyName(33, "CHN-CHINA.PNG");
            this.imageList1.Images.SetKeyName(34, "CIV-COTE D\' IVOIRE.PNG");
            this.imageList1.Images.SetKeyName(35, "CMR-CAMEROON.PNG");
            this.imageList1.Images.SetKeyName(36, "COD-DEMOCRATIC REPUBLIC OF THE CONGO.PNG");
            this.imageList1.Images.SetKeyName(37, "COL-COLOMBIA.PNG");
            this.imageList1.Images.SetKeyName(38, "COM-COMOROS.PNG");
            this.imageList1.Images.SetKeyName(39, "CPV-CAPE VERDE.PNG");
            this.imageList1.Images.SetKeyName(40, "CRC-COSTA RICA.PNG");
            this.imageList1.Images.SetKeyName(41, "CRO-CROATIA.PNG");
            this.imageList1.Images.SetKeyName(42, "CUB-CUBA.PNG");
            this.imageList1.Images.SetKeyName(43, "CYP-CYPRUS.PNG");
            this.imageList1.Images.SetKeyName(44, "CZE-CZECH.PNG");
            this.imageList1.Images.SetKeyName(45, "DEN-DENMAK.PNG");
            this.imageList1.Images.SetKeyName(46, "DJI-DJIIBOUTI.PNG");
            this.imageList1.Images.SetKeyName(47, "DOM-DOMINICAN REPUBLIC.PNG");
            this.imageList1.Images.SetKeyName(48, "ECU-ECUADOR.PNG");
            this.imageList1.Images.SetKeyName(49, "EGY-EGYPT.PNG");
            this.imageList1.Images.SetKeyName(50, "ERI-ERITREA.PNG");
            this.imageList1.Images.SetKeyName(51, "ESA-ELSALVADOR.PNG");
            this.imageList1.Images.SetKeyName(52, "ESP-SPAIN.PNG");
            this.imageList1.Images.SetKeyName(53, "EST-ESTONIA.PNG");
            this.imageList1.Images.SetKeyName(54, "ETH-ETHIOPIA.PNG");
            this.imageList1.Images.SetKeyName(55, "FIJ-FIJI.PNG");
            this.imageList1.Images.SetKeyName(56, "FIN-FINLAND.PNG");
            this.imageList1.Images.SetKeyName(57, "FRA-FRANCE.PNG");
            this.imageList1.Images.SetKeyName(58, "FSM-MICRONESIA.PNG");
            this.imageList1.Images.SetKeyName(59, "GAB-GABON.PNG");
            this.imageList1.Images.SetKeyName(60, "GAM-GAMBIA.PNG");
            this.imageList1.Images.SetKeyName(61, "GBR-UNITED KINGDOM.PNG");
            this.imageList1.Images.SetKeyName(62, "GBS-GUINEABISSAU.PNG");
            this.imageList1.Images.SetKeyName(63, "GEQ-EQUATORIALGUINEA.PNG");
            this.imageList1.Images.SetKeyName(64, "GER-GERMANY.PNG");
            this.imageList1.Images.SetKeyName(65, "GHA-GHANA.PNG");
            this.imageList1.Images.SetKeyName(66, "GRE-GREECE.PNG");
            this.imageList1.Images.SetKeyName(67, "GRN-GRENADA.PNG");
            this.imageList1.Images.SetKeyName(68, "GUA-GUATEMALA.PNG");
            this.imageList1.Images.SetKeyName(69, "GUI-GUINEA.PNG");
            this.imageList1.Images.SetKeyName(70, "GUY-GUYANA.PNG");
            this.imageList1.Images.SetKeyName(71, "HAI-HAITI.PNG");
            this.imageList1.Images.SetKeyName(72, "HON-HONDURAS.PNG");
            this.imageList1.Images.SetKeyName(73, "HUN-HUNGARY.PNG");
            this.imageList1.Images.SetKeyName(74, "INA-INDONESIA.PNG");
            this.imageList1.Images.SetKeyName(75, "IND-INDIA.PNG");
            this.imageList1.Images.SetKeyName(76, "IRI-IRAN.PNG");
            this.imageList1.Images.SetKeyName(77, "IRL-IRELAND.PNG");
            this.imageList1.Images.SetKeyName(78, "IRQ-IRAQ.PNG");
            this.imageList1.Images.SetKeyName(79, "ISL-ICELAND.PNG");
            this.imageList1.Images.SetKeyName(80, "ISR-ISRAEL.PNG");
            this.imageList1.Images.SetKeyName(81, "ITA-ITALY.PNG");
            this.imageList1.Images.SetKeyName(82, "JAM-JAMAICA.PNG");
            this.imageList1.Images.SetKeyName(83, "JOR-JORDAN.PNG");
            this.imageList1.Images.SetKeyName(84, "JPN-JAPAN.PNG");
            this.imageList1.Images.SetKeyName(85, "KAZ-KAZAKHSTAN.PNG");
            this.imageList1.Images.SetKeyName(86, "KEN-KENYA.PNG");
            this.imageList1.Images.SetKeyName(87, "KGZ-KYRGYZSTAN.PNG");
            this.imageList1.Images.SetKeyName(88, "KOR-KOREA.PNG");
            this.imageList1.Images.SetKeyName(89, "KSA-SAUDI.PNG");
            this.imageList1.Images.SetKeyName(90, "KUW-KUWAIT.PNG");
            this.imageList1.Images.SetKeyName(91, "LAO-LAOS.PNG");
            this.imageList1.Images.SetKeyName(92, "LAT-LATVIA.PNG");
            this.imageList1.Images.SetKeyName(93, "LBA-LIBYA.PNG");
            this.imageList1.Images.SetKeyName(94, "LBR-LIBERIA.PNG");
            this.imageList1.Images.SetKeyName(95, "LCA-ST.LUCIA.PNG");
            this.imageList1.Images.SetKeyName(96, "LES-LESOTHO.PNG");
            this.imageList1.Images.SetKeyName(97, "LIB-LEBANON.PNG");
            this.imageList1.Images.SetKeyName(98, "LIECHTENSTEIN.PNG");
            this.imageList1.Images.SetKeyName(99, "LTU-LITHUANIA.PNG");
            this.imageList1.Images.SetKeyName(100, "LUX-LUXEMBOURG.PNG");
            this.imageList1.Images.SetKeyName(101, "MAD-MADAGASCAR.PNG");
            this.imageList1.Images.SetKeyName(102, "MAR-MOROCCO.PNG");
            this.imageList1.Images.SetKeyName(103, "MAS-MALAYSIA.PNG");
            this.imageList1.Images.SetKeyName(104, "MAW-MALAWI.PNG");
            this.imageList1.Images.SetKeyName(105, "MAY0MYANMAR.PNG");
            this.imageList1.Images.SetKeyName(106, "MDA-MOLDOVA.PNG");
            this.imageList1.Images.SetKeyName(107, "MDV-MALDIVES.PNG");
            this.imageList1.Images.SetKeyName(108, "MEX-MEXICO.PNG");
            this.imageList1.Images.SetKeyName(109, "MGL-MONGOLIA.PNG");
            this.imageList1.Images.SetKeyName(110, "MKD-MACEDONIA.PNG");
            this.imageList1.Images.SetKeyName(111, "MLI-MALI.PNG");
            this.imageList1.Images.SetKeyName(112, "MLT-MALTA.PNG");
            this.imageList1.Images.SetKeyName(113, "MNT-MAURITANIA.PNG");
            this.imageList1.Images.SetKeyName(114, "MON-MONACO.PNG");
            this.imageList1.Images.SetKeyName(115, "MOZAMBIQUE.PNG");
            this.imageList1.Images.SetKeyName(116, "MRI-MAURITIUS.PNG");
            this.imageList1.Images.SetKeyName(117, "NAM-NAMIBIA.PNG");
            this.imageList1.Images.SetKeyName(118, "NCA-NICARAGUA.PNG");
            this.imageList1.Images.SetKeyName(119, "NED-NETHERLANDS.PNG");
            this.imageList1.Images.SetKeyName(120, "NEP-NEPAL.PNG");
            this.imageList1.Images.SetKeyName(121, "NGR-NIGERIA.PNG");
            this.imageList1.Images.SetKeyName(122, "NIG-NIGER.PNG");
            this.imageList1.Images.SetKeyName(123, "NOR-NORWAY.PNG");
            this.imageList1.Images.SetKeyName(124, "NRU-NAURU.PNG");
            this.imageList1.Images.SetKeyName(125, "NZL-NEW_ZEALAND.PNG");
            this.imageList1.Images.SetKeyName(126, "OMA-OMAN.PNG");
            this.imageList1.Images.SetKeyName(127, "PAK-PAKISTAN.PNG");
            this.imageList1.Images.SetKeyName(128, "PAN-PANAMA.PNG");
            this.imageList1.Images.SetKeyName(129, "PAR-PARAGUAY.PNG");
            this.imageList1.Images.SetKeyName(130, "PER-PERU.PNG");
            this.imageList1.Images.SetKeyName(131, "PHI-PHILIPPINES.PNG");
            this.imageList1.Images.SetKeyName(132, "PLW-PALAU.PNG");
            this.imageList1.Images.SetKeyName(133, "PNG-PAPUANEW GUINEA.PNG");
            this.imageList1.Images.SetKeyName(134, "POL-POLAND.PNG");
            this.imageList1.Images.SetKeyName(135, "POR-PORTUGAL.PNG");
            this.imageList1.Images.SetKeyName(136, "PRK-NORTH KOREA.PNG");
            this.imageList1.Images.SetKeyName(137, "QAT-QATAR.PNG");
            this.imageList1.Images.SetKeyName(138, "ROM-ROMANIA.PNG");
            this.imageList1.Images.SetKeyName(139, "ROM-RWANDA.PNG");
            this.imageList1.Images.SetKeyName(140, "RSA-SOUTH AFRICA.PNG");
            this.imageList1.Images.SetKeyName(141, "RUS-RUSSIA.PNG");
            this.imageList1.Images.SetKeyName(142, "SAM-SAMOA.PNG");
            this.imageList1.Images.SetKeyName(143, "SEN-SENEGAL.PNG");
            this.imageList1.Images.SetKeyName(144, "SEY-SEYCHELLES.PNG");
            this.imageList1.Images.SetKeyName(145, "SIN-SINGAPORE.PNG");
            this.imageList1.Images.SetKeyName(146, "SKN-NEVIS.PNG");
            this.imageList1.Images.SetKeyName(147, "SLE-SIERRA LEONE.PNG");
            this.imageList1.Images.SetKeyName(148, "SLO-SLOVENIANA.PNG");
            this.imageList1.Images.SetKeyName(149, "SMR-SAN MARINO.PNG");
            this.imageList1.Images.SetKeyName(150, "SOL-SOLOMONLSLANDS.PNG");
            this.imageList1.Images.SetKeyName(151, "SOM-SOMALIA.PNG");
            this.imageList1.Images.SetKeyName(152, "SRI-SRI LANKA.PNG");
            this.imageList1.Images.SetKeyName(153, "STP-PRINCIPE.PNG");
            this.imageList1.Images.SetKeyName(154, "SUD-SUDAN.PNG");
            this.imageList1.Images.SetKeyName(155, "SUI-SWITZERLAND.PNG");
            this.imageList1.Images.SetKeyName(156, "SUR-SURINAM.PNG");
            this.imageList1.Images.SetKeyName(157, "SVK-SLOVAKIA.PNG");
            this.imageList1.Images.SetKeyName(158, "SWE-SWEDEN.PNG");
            this.imageList1.Images.SetKeyName(159, "SWZ-SWAZILAND.PNG");
            this.imageList1.Images.SetKeyName(160, "SYR-SYRIA.PNG");
            this.imageList1.Images.SetKeyName(161, "TAN-TANZANIA.PNG");
            this.imageList1.Images.SetKeyName(162, "TGA-TONGA.PNG");
            this.imageList1.Images.SetKeyName(163, "THA-THAILAND.PNG");
            this.imageList1.Images.SetKeyName(164, "TKM-TURKMENISTAN.PNG");
            this.imageList1.Images.SetKeyName(165, "TOG-TOGO.PNG");
            this.imageList1.Images.SetKeyName(166, "TPE-TAIWAN.PNG");
            this.imageList1.Images.SetKeyName(167, "TRI-TRINIDAD AND TOBAGO.PNG");
            this.imageList1.Images.SetKeyName(168, "TUN-TUNISIA.PNG");
            this.imageList1.Images.SetKeyName(169, "TUR-TURKEY.PNG");
            this.imageList1.Images.SetKeyName(170, "UAE-UNITED ARAB EMIRATES.PNG");
            this.imageList1.Images.SetKeyName(171, "UGA-UGANDA.PNG");
            this.imageList1.Images.SetKeyName(172, "UKR-UKRAINE.PNG");
            this.imageList1.Images.SetKeyName(173, "URU-URUGUAY.PNG");
            this.imageList1.Images.SetKeyName(174, "USA-UNITED STATES.PNG");
            this.imageList1.Images.SetKeyName(175, "UZB-UZBEKISTAN.PNG");
            this.imageList1.Images.SetKeyName(176, "VAN-VANUATU.PNG");
            this.imageList1.Images.SetKeyName(177, "VEN-VENEZUELA.PNG");
            this.imageList1.Images.SetKeyName(178, "VIE-VIET NAM.PNG");
            this.imageList1.Images.SetKeyName(179, "VIN-GRENADINES.PNG");
            this.imageList1.Images.SetKeyName(180, "YEM-YEMEN.PNG");
            this.imageList1.Images.SetKeyName(181, "ZAM-ZAMBIA.PNG");
            this.imageList1.Images.SetKeyName(182, "ZIM-ZIMBABWE.PNG");
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "국가";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "국가번호";
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "AFG-AFGHANISTAN.PNG");
            this.imageList2.Images.SetKeyName(1, "ALB-ALBANIA.PNG");
            this.imageList2.Images.SetKeyName(2, "ALG-ALGERIA.PNG");
            this.imageList2.Images.SetKeyName(3, "AND-ANDORRA.PNG");
            this.imageList2.Images.SetKeyName(4, "ANG-ANGOLA.PNG");
            this.imageList2.Images.SetKeyName(5, "ANT-ANTIGUAAND BARBUDA.PNG");
            this.imageList2.Images.SetKeyName(6, "ARG-ARGENTINA.PNG");
            this.imageList2.Images.SetKeyName(7, "ARM-ARMENIA.PNG");
            this.imageList2.Images.SetKeyName(8, "AUS-AUSTRALIA.PNG");
            this.imageList2.Images.SetKeyName(9, "AUT-AUSTRIA.PNG");
            this.imageList2.Images.SetKeyName(10, "BAH-BAHAMAS.PNG");
            this.imageList2.Images.SetKeyName(11, "BAN-BANGLADESH.PNG");
            this.imageList2.Images.SetKeyName(12, "BAR-BARBADOS.PNG");
            this.imageList2.Images.SetKeyName(13, "BDI-BURUNDI.PNG");
            this.imageList2.Images.SetKeyName(14, "BEL-BELGIUM.PNG");
            this.imageList2.Images.SetKeyName(15, "BEN-BENIN.PNG");
            this.imageList2.Images.SetKeyName(16, "BHU-BHUTAN.PNG");
            this.imageList2.Images.SetKeyName(17, "BIH-BOSNIA AND HERZEGOVINA.PNG");
            this.imageList2.Images.SetKeyName(18, "BIZ-BELIZE.PNG");
            this.imageList2.Images.SetKeyName(19, "BLR-BELARUS.PNG");
            this.imageList2.Images.SetKeyName(20, "BOL-BOLIVIA.PNG");
            this.imageList2.Images.SetKeyName(21, "BOT-BOTSWANA.PNG");
            this.imageList2.Images.SetKeyName(22, "BRA-BRAZIL.PNG");
            this.imageList2.Images.SetKeyName(23, "BRN-BAHRAIN.PNG");
            this.imageList2.Images.SetKeyName(24, "BRU-BRUNEI.PNG");
            this.imageList2.Images.SetKeyName(25, "BUL-BULGARIA.PNG");
            this.imageList2.Images.SetKeyName(26, "BUR-BURKINA FASO.PNG");
            this.imageList2.Images.SetKeyName(27, "CAF-CENTRAL AFRICAN REPUBLIC.PNG");
            this.imageList2.Images.SetKeyName(28, "CAM-CAMBODIA.PNG");
            this.imageList2.Images.SetKeyName(29, "CAN-CANADA.PNG");
            this.imageList2.Images.SetKeyName(30, "CGO-CONGO.PNG");
            this.imageList2.Images.SetKeyName(31, "CHA-CHAD.PNG");
            this.imageList2.Images.SetKeyName(32, "CHI-CHILE.PNG");
            this.imageList2.Images.SetKeyName(33, "CHN-CHINA.PNG");
            this.imageList2.Images.SetKeyName(34, "CIV-COTE D\' IVOIRE.PNG");
            this.imageList2.Images.SetKeyName(35, "CMR-CAMEROON.PNG");
            this.imageList2.Images.SetKeyName(36, "COD-DEMOCRATIC REPUBLIC OF THE CONGO.PNG");
            this.imageList2.Images.SetKeyName(37, "COL-COLOMBIA.PNG");
            this.imageList2.Images.SetKeyName(38, "COM-COMOROS.PNG");
            this.imageList2.Images.SetKeyName(39, "CPV-CAPE VERDE.PNG");
            this.imageList2.Images.SetKeyName(40, "CRC-COSTA RICA.PNG");
            this.imageList2.Images.SetKeyName(41, "CRO-CROATIA.PNG");
            this.imageList2.Images.SetKeyName(42, "CUB-CUBA.PNG");
            this.imageList2.Images.SetKeyName(43, "CYP-CYPRUS.PNG");
            this.imageList2.Images.SetKeyName(44, "CZE-CZECH.PNG");
            this.imageList2.Images.SetKeyName(45, "DEN-DENMAK.PNG");
            this.imageList2.Images.SetKeyName(46, "DJI-DJIIBOUTI.PNG");
            this.imageList2.Images.SetKeyName(47, "DOM-DOMINICAN REPUBLIC.PNG");
            this.imageList2.Images.SetKeyName(48, "ECU-ECUADOR.PNG");
            this.imageList2.Images.SetKeyName(49, "EGY-EGYPT.PNG");
            this.imageList2.Images.SetKeyName(50, "ERI-ERITREA.PNG");
            this.imageList2.Images.SetKeyName(51, "ESA-ELSALVADOR.PNG");
            this.imageList2.Images.SetKeyName(52, "ESP-SPAIN.PNG");
            this.imageList2.Images.SetKeyName(53, "EST-ESTONIA.PNG");
            this.imageList2.Images.SetKeyName(54, "ETH-ETHIOPIA.PNG");
            this.imageList2.Images.SetKeyName(55, "FIJ-FIJI.PNG");
            this.imageList2.Images.SetKeyName(56, "FIN-FINLAND.PNG");
            this.imageList2.Images.SetKeyName(57, "FRA-FRANCE.PNG");
            this.imageList2.Images.SetKeyName(58, "FSM-MICRONESIA.PNG");
            this.imageList2.Images.SetKeyName(59, "GAB-GABON.PNG");
            this.imageList2.Images.SetKeyName(60, "GAM-GAMBIA.PNG");
            this.imageList2.Images.SetKeyName(61, "GBR-UNITED KINGDOM.PNG");
            this.imageList2.Images.SetKeyName(62, "GBS-GUINEABISSAU.PNG");
            this.imageList2.Images.SetKeyName(63, "GEQ-EQUATORIALGUINEA.PNG");
            this.imageList2.Images.SetKeyName(64, "GER-GERMANY.PNG");
            this.imageList2.Images.SetKeyName(65, "GHA-GHANA.PNG");
            this.imageList2.Images.SetKeyName(66, "GRE-GREECE.PNG");
            this.imageList2.Images.SetKeyName(67, "GRN-GRENADA.PNG");
            this.imageList2.Images.SetKeyName(68, "GUA-GUATEMALA.PNG");
            this.imageList2.Images.SetKeyName(69, "GUI-GUINEA.PNG");
            this.imageList2.Images.SetKeyName(70, "GUY-GUYANA.PNG");
            this.imageList2.Images.SetKeyName(71, "HAI-HAITI.PNG");
            this.imageList2.Images.SetKeyName(72, "HON-HONDURAS.PNG");
            this.imageList2.Images.SetKeyName(73, "HUN-HUNGARY.PNG");
            this.imageList2.Images.SetKeyName(74, "INA-INDONESIA.PNG");
            this.imageList2.Images.SetKeyName(75, "IND-INDIA.PNG");
            this.imageList2.Images.SetKeyName(76, "IRI-IRAN.PNG");
            this.imageList2.Images.SetKeyName(77, "IRL-IRELAND.PNG");
            this.imageList2.Images.SetKeyName(78, "IRQ-IRAQ.PNG");
            this.imageList2.Images.SetKeyName(79, "ISL-ICELAND.PNG");
            this.imageList2.Images.SetKeyName(80, "ISR-ISRAEL.PNG");
            this.imageList2.Images.SetKeyName(81, "ITA-ITALY.PNG");
            this.imageList2.Images.SetKeyName(82, "JAM-JAMAICA.PNG");
            this.imageList2.Images.SetKeyName(83, "JOR-JORDAN.PNG");
            this.imageList2.Images.SetKeyName(84, "JPN-JAPAN.PNG");
            this.imageList2.Images.SetKeyName(85, "KAZ-KAZAKHSTAN.PNG");
            this.imageList2.Images.SetKeyName(86, "KEN-KENYA.PNG");
            this.imageList2.Images.SetKeyName(87, "KGZ-KYRGYZSTAN.PNG");
            this.imageList2.Images.SetKeyName(88, "KOR-KOREA.PNG");
            this.imageList2.Images.SetKeyName(89, "KSA-SAUDI.PNG");
            this.imageList2.Images.SetKeyName(90, "KUW-KUWAIT.PNG");
            this.imageList2.Images.SetKeyName(91, "LAO-LAOS.PNG");
            this.imageList2.Images.SetKeyName(92, "LAT-LATVIA.PNG");
            this.imageList2.Images.SetKeyName(93, "LBA-LIBYA.PNG");
            this.imageList2.Images.SetKeyName(94, "LBR-LIBERIA.PNG");
            this.imageList2.Images.SetKeyName(95, "LCA-ST.LUCIA.PNG");
            this.imageList2.Images.SetKeyName(96, "LES-LESOTHO.PNG");
            this.imageList2.Images.SetKeyName(97, "LIB-LEBANON.PNG");
            this.imageList2.Images.SetKeyName(98, "LIECHTENSTEIN.PNG");
            this.imageList2.Images.SetKeyName(99, "LTU-LITHUANIA.PNG");
            this.imageList2.Images.SetKeyName(100, "LUX-LUXEMBOURG.PNG");
            this.imageList2.Images.SetKeyName(101, "MAD-MADAGASCAR.PNG");
            this.imageList2.Images.SetKeyName(102, "MAR-MOROCCO.PNG");
            this.imageList2.Images.SetKeyName(103, "MAS-MALAYSIA.PNG");
            this.imageList2.Images.SetKeyName(104, "MAW-MALAWI.PNG");
            this.imageList2.Images.SetKeyName(105, "MAY0MYANMAR.PNG");
            this.imageList2.Images.SetKeyName(106, "MDA-MOLDOVA.PNG");
            this.imageList2.Images.SetKeyName(107, "MDV-MALDIVES.PNG");
            this.imageList2.Images.SetKeyName(108, "MEX-MEXICO.PNG");
            this.imageList2.Images.SetKeyName(109, "MGL-MONGOLIA.PNG");
            this.imageList2.Images.SetKeyName(110, "MKD-MACEDONIA.PNG");
            this.imageList2.Images.SetKeyName(111, "MLI-MALI.PNG");
            this.imageList2.Images.SetKeyName(112, "MLT-MALTA.PNG");
            this.imageList2.Images.SetKeyName(113, "MNT-MAURITANIA.PNG");
            this.imageList2.Images.SetKeyName(114, "MON-MONACO.PNG");
            this.imageList2.Images.SetKeyName(115, "MOZAMBIQUE.PNG");
            this.imageList2.Images.SetKeyName(116, "MRI-MAURITIUS.PNG");
            this.imageList2.Images.SetKeyName(117, "NAM-NAMIBIA.PNG");
            this.imageList2.Images.SetKeyName(118, "NCA-NICARAGUA.PNG");
            this.imageList2.Images.SetKeyName(119, "NED-NETHERLANDS.PNG");
            this.imageList2.Images.SetKeyName(120, "NEP-NEPAL.PNG");
            this.imageList2.Images.SetKeyName(121, "NGR-NIGERIA.PNG");
            this.imageList2.Images.SetKeyName(122, "NIG-NIGER.PNG");
            this.imageList2.Images.SetKeyName(123, "NOR-NORWAY.PNG");
            this.imageList2.Images.SetKeyName(124, "NRU-NAURU.PNG");
            this.imageList2.Images.SetKeyName(125, "NZL-NEW_ZEALAND.PNG");
            this.imageList2.Images.SetKeyName(126, "OMA-OMAN.PNG");
            this.imageList2.Images.SetKeyName(127, "PAK-PAKISTAN.PNG");
            this.imageList2.Images.SetKeyName(128, "PAN-PANAMA.PNG");
            this.imageList2.Images.SetKeyName(129, "PAR-PARAGUAY.PNG");
            this.imageList2.Images.SetKeyName(130, "PER-PERU.PNG");
            this.imageList2.Images.SetKeyName(131, "PHI-PHILIPPINES.PNG");
            this.imageList2.Images.SetKeyName(132, "PLW-PALAU.PNG");
            this.imageList2.Images.SetKeyName(133, "PNG-PAPUANEW GUINEA.PNG");
            this.imageList2.Images.SetKeyName(134, "POL-POLAND.PNG");
            this.imageList2.Images.SetKeyName(135, "POR-PORTUGAL.PNG");
            this.imageList2.Images.SetKeyName(136, "PRK-NORTH KOREA.PNG");
            this.imageList2.Images.SetKeyName(137, "QAT-QATAR.PNG");
            this.imageList2.Images.SetKeyName(138, "ROM-ROMANIA.PNG");
            this.imageList2.Images.SetKeyName(139, "ROM-RWANDA.PNG");
            this.imageList2.Images.SetKeyName(140, "RSA-SOUTH AFRICA.PNG");
            this.imageList2.Images.SetKeyName(141, "RUS-RUSSIA.PNG");
            this.imageList2.Images.SetKeyName(142, "SAM-SAMOA.PNG");
            this.imageList2.Images.SetKeyName(143, "SEN-SENEGAL.PNG");
            this.imageList2.Images.SetKeyName(144, "SEY-SEYCHELLES.PNG");
            this.imageList2.Images.SetKeyName(145, "SIN-SINGAPORE.PNG");
            this.imageList2.Images.SetKeyName(146, "SKN-NEVIS.PNG");
            this.imageList2.Images.SetKeyName(147, "SLE-SIERRA LEONE.PNG");
            this.imageList2.Images.SetKeyName(148, "SLO-SLOVENIANA.PNG");
            this.imageList2.Images.SetKeyName(149, "SMR-SAN MARINO.PNG");
            this.imageList2.Images.SetKeyName(150, "SOL-SOLOMONLSLANDS.PNG");
            this.imageList2.Images.SetKeyName(151, "SOM-SOMALIA.PNG");
            this.imageList2.Images.SetKeyName(152, "SRI-SRI LANKA.PNG");
            this.imageList2.Images.SetKeyName(153, "STP-PRINCIPE.PNG");
            this.imageList2.Images.SetKeyName(154, "SUD-SUDAN.PNG");
            this.imageList2.Images.SetKeyName(155, "SUI-SWITZERLAND.PNG");
            this.imageList2.Images.SetKeyName(156, "SUR-SURINAM.PNG");
            this.imageList2.Images.SetKeyName(157, "SVK-SLOVAKIA.PNG");
            this.imageList2.Images.SetKeyName(158, "SWE-SWEDEN.PNG");
            this.imageList2.Images.SetKeyName(159, "SWZ-SWAZILAND.PNG");
            this.imageList2.Images.SetKeyName(160, "SYR-SYRIA.PNG");
            this.imageList2.Images.SetKeyName(161, "TAN-TANZANIA.PNG");
            this.imageList2.Images.SetKeyName(162, "TGA-TONGA.PNG");
            this.imageList2.Images.SetKeyName(163, "THA-THAILAND.PNG");
            this.imageList2.Images.SetKeyName(164, "TKM-TURKMENISTAN.PNG");
            this.imageList2.Images.SetKeyName(165, "TOG-TOGO.PNG");
            this.imageList2.Images.SetKeyName(166, "TPE-TAIWAN.PNG");
            this.imageList2.Images.SetKeyName(167, "TRI-TRINIDAD AND TOBAGO.PNG");
            this.imageList2.Images.SetKeyName(168, "TUN-TUNISIA.PNG");
            this.imageList2.Images.SetKeyName(169, "TUR-TURKEY.PNG");
            this.imageList2.Images.SetKeyName(170, "UAE-UNITED ARAB EMIRATES.PNG");
            this.imageList2.Images.SetKeyName(171, "UGA-UGANDA.PNG");
            this.imageList2.Images.SetKeyName(172, "UKR-UKRAINE.PNG");
            this.imageList2.Images.SetKeyName(173, "URU-URUGUAY.PNG");
            this.imageList2.Images.SetKeyName(174, "USA-UNITED STATES.PNG");
            this.imageList2.Images.SetKeyName(175, "UZB-UZBEKISTAN.PNG");
            this.imageList2.Images.SetKeyName(176, "VAN-VANUATU.PNG");
            this.imageList2.Images.SetKeyName(177, "VEN-VENEZUELA.PNG");
            this.imageList2.Images.SetKeyName(178, "VIE-VIET NAM.PNG");
            this.imageList2.Images.SetKeyName(179, "VIN-GRENADINES.PNG");
            this.imageList2.Images.SetKeyName(180, "YEM-YEMEN.PNG");
            this.imageList2.Images.SetKeyName(181, "ZAM-ZAMBIA.PNG");
            this.imageList2.Images.SetKeyName(182, "ZIM-ZIMBABWE.PNG");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 545);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Name = "Form1";
            this.RightToLeftLayout = true;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ImageList imageList2;
    }
}

