﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _11_16_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Random r = new Random();
            listView1.BeginUpdate();
            for (int i = 0; i < 100; i++) 
            {
                int n1 = r.Next(10001, 100000);
                int n2 = r.Next(0, 101);
                int n3 = r.Next(0, 101);
                int n6 = r.Next(0, 101);
                int n4 = r.Next(0, 10);
                int n5 = r.Next(0, 12);
                int s = n2 + n3 + n6;

                ListViewItem lv = new ListViewItem("2011" + n1);
                String[] str = { "김", "이", "박", "최", "장", "전", "강", "윤", "조", "지" };
                String[] str1 = { "장", "이", "박", "최", "장", "전", "강", "윤", "조", "지", "아", "구" };
                String[] str2 = { "장", "이", "박", "최", "장", "전", "강", "윤", "조", "지", "아", "구" };

                lv.SubItems.Add("" + str[n4] + str1[n5] + str2[n5]);
                lv.SubItems.Add("" + n2);
                lv.SubItems.Add("" + n3);
                lv.SubItems.Add("" + n6);
                lv.SubItems.Add("" + s);
                listView1.Items.Add(lv);
            }
            listView1.EndUpdate();
        }

    }
}
